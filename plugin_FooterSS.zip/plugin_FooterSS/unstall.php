<?php

defined('WP_UNINSTALL_PLUGIN') or die('kill.');
